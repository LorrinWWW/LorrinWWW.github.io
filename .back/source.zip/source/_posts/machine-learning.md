---
title: machine learning
date: 2016-12-12 22:04:47
categories: [programming, unfinished]
tags: [machine-learning]
---

# 笔记

这里先占个位，等有空来填。

# 参考

[轻松看懂机器学习十大常用算法](http://blog.jobbole.com/108395/?utm_source=blog.jobbole.com&utm_medium=relatedPosts)